package malom;

public class ponthely {
	private int x, y;
	Hely h;
	
	public ponthely(int X, int Y, Hely H) {
		x = X;
		y = Y;
		h = H;
	}
	
	public int getX() {
		return x;
	}
	
	public int getY() {
		return y;
	}
	
	public Hely getHely() {
		return h;
	}
}
